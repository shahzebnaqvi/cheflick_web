<?php
echo "sasas";
print_r( $_POST);
// $data  = print_r( $_POST);
// json_decode($data);
// $data = array(
//     'product_id' => $_POST['product_id'],
//     'quantity' => $_POST['quantity'],
//     'variation_id' => $_POST['variation_id'],
//     'variation' => $_POST['variation'],
//     'cart_item_data' => $_POST['cart_item_data']
// );


?>