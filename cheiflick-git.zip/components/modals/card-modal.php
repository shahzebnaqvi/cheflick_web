<div class="modal fade" id="cardModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >

  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
  
      <div class="modal-body">
          <div style="width: 100%">
 <p style="font-weight:600; font-size: 24px; color:#001746">Add New Card</p>
                      
          <div class="row">
                <div class="form-group col-md-12 ">
                <label>Account Title</label><br>
                <input type="text" class="form-control shadow-lg  bg-white rounded" placeholder="Accoutn Title"  style="border-radius: 10px;border-color:#E1E1E1;" />
                </div>
           <div class="form-group col-md-12 " >
                  <label>Account Number</label>
                  <input type="text" class="form-control shadow-lg  bg-white rounded" placeholder="Account Number"  style="border-radius: 10px;border-color:#E1E1E1;" />
                
            </div>
          </div>
          <div class="row">
              <div class=" form-group col-lg-6">
                  <label>Exp Date</label>
           
                <input type="text" class="form-control shadow-lg  bg-white rounded" placeholder="01/22"  style="border-radius: 10px;border-color:#E1E1E1;" />
            </div>
            <div class=" form-group col-lg-6">
                <label>CVV Number</label>
           
           <input type="number" class="form-control shadow-lg  bg-white rounded" placeholder="CVV Code"  style="border-radius: 10px;border-color:#E1E1E1;" />
            </div>
          </div>
          <div class="row">
           <div class="form-group col-md-12 " >
                  
            <button class="rate" data-dismiss="modal">Add New Card</button>
            </div>
                
            </div>
          </div>
          </div>
      </div>
    </div>
  </div>
</div>