<div class="modal" id="modal1">
	<div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        
        <div class="modal-body">
            <div class="modalCard">
                <div class="row py-2 px-2">
                    <div class="col-sm-6">
                        <p class="bold voucherHead">Apply Voucher</p>
                    </div>
                    <div class="col-sm-6">
                        <a data-toggle="modal" href="#modal2" class="voucher-btn">Apply Voucher</a>
                    </div>
            </div>
                <div class="row voucherModal mb-2">
                    <div class="col-sm-6">
                        <p class="bold">500 off on </p>
                        <p class="card-texttt">Code: <span class="orderText">5sgavw</span></p>
                    </div>
                    <div class="col-sm-6">
                        <p class="cardTextt">Expiry: <span class="bold">10-Feb-2022</span></p>
                        <p class="text-end"><span class="orderTextt">Rs. 500</span></p>
                    </div>
                </div>
                <div class="row voucherModal mb-2">
                    <div class="col-sm-6">
                        <p class="bold">500 off on </p>
                        <p class="card-texttt">Code: <span class="orderText">5sgavw</span></p>
                    </div>
                    <div class="col-sm-6">
                        <p class="cardTextt">Expiry: <span class="bold">10-Feb-2022</span></p>
                        <p class="text-end"><span class="orderTextt">Rs. 500</span></p>
                    </div>
                </div>
                <div class="row voucherModal mb-2">
                    <div class="col-sm-6">
                        <p class="bold">500 off on </p>
                        <p class="card-texttt">Code: <span class="orderText">5sgavw</span></p>
                    </div>
                    <div class="col-sm-6">
                        <p class="cardTextt">Expiry: <span class="bold">10-Feb-2022</span></p>
                        <p class="text-end"><span class="orderTextt">Rs. 500</span></p>
                    </div>
                </div>
                <div class="row voucherModal mb-2">
                    <div class="col-sm-6">
                        <p class="bold">500 off on </p>
                        <p class="card-texttt">Code: <span class="orderText">5sgavw</span></p>
                    </div>
                    <div class="col-sm-6">
                        <p class="cardTextt">Expiry: <span class="bold">10-Feb-2022</span></p>
                        <p class="text-end"><span class="orderTextt">Rs. 500</span></p>
                    </div>
                </div>
            </div>
          <button data-toggle="modal" href="#modal2" class="rate2">ADD NEW VOUCHER</button>
        </div>
      </div>
    </div>
</div>
<div class="modal" id="modal2" data-backdrop="static">
	<div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="container containerCustom"></div>
        <div class="modal-body">
            <div class="row py-2 px-2">
                    <div class="col-sm-12">
                        <p class="bold voucherHead">Apply New Voucher</p>
                    </div>
            </div>
            <div class="row mb-2 mt-2">
        <div class="col-lg-12">
          <div class="col-md-12 input-group input-group-lg voucherInput">
                <input type="text" class="form-control" placeholder="K-909, block 6, PECHS" />
            </div>
        </div>
    </div>
          <button data-dismiss="modal" href="#modal2" class="rate2">ADD NEW VOUCHER</button>
        </div>
      </div>
    </div>
</div>